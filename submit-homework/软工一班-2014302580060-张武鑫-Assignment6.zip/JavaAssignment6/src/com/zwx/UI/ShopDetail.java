package com.zwx.UI;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

import javax.swing.JTextField;

import com.zwx.dao.BuyDao;

public class ShopDetail extends JFrame {
    String[] list1={"1","��","1000","0"};
    String[] list2={"2","è","1024","0"};
    
    String[] list3={"3","��","135","0"};
    //String[] list4={"4","�ʼǱ�3","3","0"};
    int flag = 0;
    double sum=0;
    private JPanel contentPane;
    private JLabel lblNewLabel;
    private JPanel panel;
    private JPanel panel_1;
    private JButton btnNewButton;
    private JButton btnNewButton_1;
    private JPanel panel_2;
    private JPanel panel_3;
    private JLabel lblNewLabel_1;
    private JLabel lblNewLabel_2;
    private JLabel lblNewLabel_3;
    private JLabel lblNewLabel_4;
    private JLabel lblNewLabel_5;
    private JLabel lblNewLabel_6;
    private JLabel lblNewLabel_7;
    private JLabel lblNewLabel_8;
    private JLabel lblNewLabel_9;
    private JLabel lblNewLabel_10;
    private JLabel lblNewLabel_11;
    private JLabel lblNewLabel_12;
    private JLabel lblNewLabel_13;
    private JLabel lblNewLabel_14;
    private JLabel lblNewLabel_15;
    private JLabel lblNewLabel_16;
    private JLabel lblNewLabel_17;
    private JLabel lblNewLabel_18;
    private JLabel lblNewLabel_19;
    private JLabel lblNewLabel_20;
    private JLabel lblNewLabel_21;
    private JLabel lblNewLabel_22;
    private JButton btnNewButton_2;
    private String username;
    private int type;


    public  ShopDetail(String username, int type) {
    	this.username = username;
    	this.type = type;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("�����嵥");
        setBounds(100, 100, 483, 528);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);
        
        panel = new JPanel();
        contentPane.add(panel, BorderLayout.NORTH);
        
        lblNewLabel = new JLabel("�����嵥");
        panel.add(lblNewLabel);
        
        panel_1 = new JPanel();
        contentPane.add(panel_1, BorderLayout.SOUTH);
        
        btnNewButton = new JButton("����");
        panel_1.add(btnNewButton);
        
    
    
        
        panel_2 = new JPanel();
        contentPane.add(panel_2, BorderLayout.CENTER);
        panel_2.setLayout(new GridLayout(0, 4, 4, 0));
        
        panel_3 = new JPanel();
        panel_2.add(panel_3);
        
        lblNewLabel_1 = new JLabel("��Ʒ���");
        panel_3.add(lblNewLabel_1);
        
        JPanel panel_4 = new JPanel();
        panel_2.add(panel_4);
        
        lblNewLabel_2 = new JLabel("����");
        panel_4.add(lblNewLabel_2);
        
        JPanel panel_5 = new JPanel();
        panel_2.add(panel_5);
        
        lblNewLabel_3 = new JLabel("����(Ԫ)");
        panel_5.add(lblNewLabel_3);
        
        JPanel panel_6 = new JPanel();
        panel_2.add(panel_6);
        
        lblNewLabel_4 = new JLabel("����");
        panel_6.add(lblNewLabel_4);
        
        JPanel panel_7 = new JPanel();
        panel_2.add(panel_7);
        
        lblNewLabel_5 = new JLabel();
        panel_7.add(lblNewLabel_5);
        
        JPanel panel_8 = new JPanel();
        panel_2.add(panel_8);
        
        lblNewLabel_6 = new JLabel();
        panel_8.add(lblNewLabel_6);
        
        JPanel panel_9 = new JPanel();
        panel_2.add(panel_9);
        
        lblNewLabel_7 = new JLabel();
        panel_9.add(lblNewLabel_7);
        
        JPanel panel_10 = new JPanel();
        panel_2.add(panel_10);
        
        lblNewLabel_8 = new JLabel();
        panel_10.add(lblNewLabel_8);
        
        JPanel panel_11 = new JPanel();
        panel_2.add(panel_11);
        
        lblNewLabel_9 = new JLabel();
        panel_11.add(lblNewLabel_9);
        
        JPanel panel_12 = new JPanel();
        panel_2.add(panel_12);
        
        lblNewLabel_10 = new JLabel();
        panel_12.add(lblNewLabel_10);
        
        JPanel panel_13 = new JPanel();
        panel_2.add(panel_13);
        
        lblNewLabel_11 = new JLabel();
        panel_13.add(lblNewLabel_11);
        
        JPanel panel_14 = new JPanel();
        panel_2.add(panel_14);
        
        lblNewLabel_12 = new JLabel();
        panel_14.add(lblNewLabel_12);
        
        JPanel panel_15 = new JPanel();
        panel_2.add(panel_15);
        
        lblNewLabel_13 = new JLabel();
        panel_15.add(lblNewLabel_13);
        
        JPanel panel_16 = new JPanel();
        panel_2.add(panel_16);
        
        lblNewLabel_14 = new JLabel();
        panel_16.add(lblNewLabel_14);
        
        JPanel panel_17 = new JPanel();
        panel_2.add(panel_17);
        
        lblNewLabel_15 = new JLabel();
        panel_17.add(lblNewLabel_15);
        
        JPanel panel_18 = new JPanel();
        panel_2.add(panel_18);
        
        lblNewLabel_16 = new JLabel();
        panel_18.add(lblNewLabel_16);
        
        JPanel panel_19 = new JPanel();
        panel_2.add(panel_19);
        
        lblNewLabel_17 = new JLabel();
        panel_19.add(lblNewLabel_17);
        
        JPanel panel_20 = new JPanel();
        panel_2.add(panel_20);
        
        lblNewLabel_18 = new JLabel("");
        panel_20.add(lblNewLabel_18);
        
        JPanel panel_21 = new JPanel();
        panel_2.add(panel_21);
        
        lblNewLabel_19 = new JLabel("");
        panel_21.add(lblNewLabel_19);
        
        JPanel panel_22 = new JPanel();
        panel_2.add(panel_22);
        
        lblNewLabel_20 = new JLabel("");
        panel_22.add(lblNewLabel_20);
        
        JPanel panel_23 = new JPanel();
        panel_2.add(panel_23);
        
        lblNewLabel_21 = new JLabel("�ܼۣ�");
        panel_23.add(lblNewLabel_21);
        
        JPanel panel_24 = new JPanel();
        panel_2.add(panel_24);
        
        lblNewLabel_22 = new JLabel("0Ԫ");
        panel_24.add(lblNewLabel_22);
    
        setVisible(true);
btnNewButton.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
            	String pid,num;
                if(!lblNewLabel_5.getText().isEmpty())
                {
                	pid = lblNewLabel_5.getText();
                	num = lblNewLabel_8.getText();
                	try {
						BuyDao.addProd(ShopDetail.this.username, pid, num);
					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
                }
                if(!lblNewLabel_9.getText().isEmpty())
                {
                	pid = lblNewLabel_9.getText();
                	num = lblNewLabel_12.getText();
                	try {
						BuyDao.addProd(ShopDetail.this.username, pid, num);
					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
                }
                if(!lblNewLabel_13.getText().isEmpty())
                {
                	pid = lblNewLabel_13.getText();
                	num = lblNewLabel_16.getText();
                	try {
						BuyDao.addProd(ShopDetail.this.username, pid, num);
					} catch (Exception e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
                }
                
                if(lblNewLabel_13.getText().isEmpty() &&lblNewLabel_9.getText().isEmpty() &&lblNewLabel_5.getText().isEmpty() )
                	JOptionPane.showMessageDialog(null, "ʲô��û��", "Warning", JOptionPane.ERROR_MESSAGE);
                else JOptionPane.showMessageDialog(null, "����ɹ�", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    	if(type == 1)
    	{
    		btnNewButton.setVisible(false);
    		lblNewLabel.setText("�ѹ���Ʒ");
    		List<Map<String,Object>> lis = BuyDao.findProd(username);
    		if (lis.size() == 0)
    		{
    			JOptionPane.showMessageDialog(null, "û���ҵ������¼", "Warning", JOptionPane.ERROR_MESSAGE);
    			this.dispose();
    		}
    		for(Map<String,Object> map : lis)
    		{
    			list_1(map.get("pid").toString(),map.get("num").toString());
    		}
    	}
    
    }
    public void list_1(String str1,String str2){
        if(str1.equals(list1[0]))
        {
            lblNewLabel_5.setText(list1[0]);
            lblNewLabel_6.setText(list1[1]);
            lblNewLabel_7.setText(list1[2]);
            list1[3]=str2;
            lblNewLabel_8.setText(list1[3]);
            Double d1 = new Double(list1[2]);
            Double d2 = new Double(list1[3]);
            sum =sum+ d1*d2;
        }
        if(str1.equals(list2[0]))
        {
            lblNewLabel_9.setText(list2[0]);
            lblNewLabel_10.setText(list2[1]);
            lblNewLabel_11.setText(list2[2]);
            list2[3]=str2;
            lblNewLabel_12.setText(list2[3]);
            Double d3 = new Double(list2[2]);
            Double d4 = new Double(list2[3]);
            sum =sum+ d3*d4;
        }
        if(str1.equals(list3[0]))
        {
            lblNewLabel_13.setText(list3[0]);
            lblNewLabel_14.setText(list3[1]);
            lblNewLabel_15.setText(list3[2]);
            
            list3[3]=str2;
            lblNewLabel_16.setText(list3[3]);
            Double d5 = new Double(list3[2]);
            Double d6 = new Double(list3[3]);
            sum =sum+ d5*d6;
        }
        
        lblNewLabel_22.setText(sum+"Ԫ");
        
    }
    
    

}