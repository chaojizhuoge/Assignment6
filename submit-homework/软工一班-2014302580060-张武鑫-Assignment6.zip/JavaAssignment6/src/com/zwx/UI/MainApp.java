package com.zwx.UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.BorderLayout;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import com.zwx.dao.UserDao;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainApp {

	private JFrame frmWelcomeTo;
	private JTextField text_username;
	private JPasswordField text_password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainApp window = new MainApp();
					window.frmWelcomeTo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainApp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmWelcomeTo = new JFrame();
		frmWelcomeTo.setTitle("Welcome");
		frmWelcomeTo.setBounds(100, 100, 450, 300);
		frmWelcomeTo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmWelcomeTo.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel.setBounds(74, 53, 71, 47);
		frmWelcomeTo.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801\uFF1A");
		lblNewLabel_1.setBounds(74, 144, 71, 38);
		frmWelcomeTo.getContentPane().add(lblNewLabel_1);
		
		text_username = new JTextField();
		text_username.setBounds(155, 66, 159, 21);
		frmWelcomeTo.getContentPane().add(text_username);
		text_username.setColumns(10);
		
		text_password = new JPasswordField();
		text_password.setBounds(155, 153, 159, 21);
		frmWelcomeTo.getContentPane().add(text_password);
		
		JButton btn_login = new JButton("\u767B\u9646");
		btn_login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				UserDao userdao = new UserDao();
				String username = text_username.getText();
				String pwd = text_password.getText();
				if(username.isEmpty() || pwd.isEmpty() )
				{
					JOptionPane.showMessageDialog(null, "����д������Ϣ��", "Warning", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					if(userdao.checkUser(username, pwd))
					{
						PetsFrame pf = new PetsFrame(username);
						pf.setVisible(true);
						MainApp.this.frmWelcomeTo.setVisible(false);
					}
					else JOptionPane.showMessageDialog(null, "�û���/�������", "Warning", JOptionPane.ERROR_MESSAGE);
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
		});
		btn_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btn_login.setBounds(74, 206, 93, 23);
		frmWelcomeTo.getContentPane().add(btn_login);
		
		JButton btn_reg = new JButton("\u6CE8\u518C");
		btn_reg.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				RegFrame reg = new RegFrame();
				reg.setVisible(true);
				
			}
		});
		btn_reg.setBounds(280, 206, 93, 23);
		frmWelcomeTo.getContentPane().add(btn_reg);
	}
}
