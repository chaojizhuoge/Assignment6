package com.zwx.UI;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;


import com.zwx.dao.MailDao;
import com.zwx.dao.UserDao;
import com.zwx.util.MailSenderInfo;
import com.zwx.util.SimpleMailSender;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RegFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5233401246523961625L;
	private JTextField text_username;
	private JPasswordField text_pwd;
	private JPasswordField text_rpwd;
	private JTextField text_email;
	private JTextField text_yanz;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public RegFrame() {
		setTitle("\u6CE8\u518C");
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D");
		lblNewLabel.setBounds(89, 54, 54, 15);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801");
		lblNewLabel_1.setBounds(89, 79, 54, 15);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u518D\u6B21\u8F93\u5165\u5BC6\u7801");
		lblNewLabel_2.setBounds(89, 104, 96, 15);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u90AE\u7BB1");
		lblNewLabel_3.setBounds(89, 129, 54, 15);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u9A8C\u8BC1\u7801");
		lblNewLabel_4.setBounds(89, 154, 54, 15);
		getContentPane().add(lblNewLabel_4);
		
		text_username = new JTextField();
		text_username.setBounds(175, 51, 161, 21);
		getContentPane().add(text_username);
		text_username.setColumns(10);
		
		text_pwd = new JPasswordField();
		text_pwd.setBounds(175, 76, 161, 21);
		getContentPane().add(text_pwd);
		
		text_rpwd = new JPasswordField();
		text_rpwd.setBounds(175, 101, 161, 21);
		getContentPane().add(text_rpwd);
		
		text_email = new JTextField();
		text_email.setBounds(175, 126, 161, 21);
		getContentPane().add(text_email);
		text_email.setColumns(10);
		
		text_yanz = new JTextField();
		text_yanz.setBounds(175, 151, 66, 21);
		getContentPane().add(text_yanz);
		text_yanz.setColumns(10);
		
		JButton btn_yanz = new JButton("\u83B7\u53D6\u9A8C\u8BC1\u7801");
		btn_yanz.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String mailID = text_email.getText();
				if(mailID.isEmpty())
				{
					JOptionPane.showMessageDialog(null, "������email��ַ", "Warning", JOptionPane.ERROR_MESSAGE);
					return;
				}
				int i1 = (int)(Math.random()*9);
				int i2 = (int)(Math.random()*9);
				int i3 = (int)(Math.random()*9);
				int i4 = (int)(Math.random()*9);
				String checkNum = String.valueOf(i1)+String.valueOf(i2)+String.valueOf(i3)+String.valueOf(i4);
				System.out.println(checkNum);
				try{
					if(MailDao.existMail(mailID, 1))
					{
						MailDao.deleteFromMail(mailID);
						//System.out.println("123");
					}
					if(!MailDao.existMail(mailID,2))
					{
						MailDao.addMailCheck(mailID, checkNum);
						try{
						MailSenderInfo mailInfo = new MailSenderInfo();   
					      mailInfo.setMailServerHost("smtp.139.com");   
					      mailInfo.setMailServerPort("25");   
					      mailInfo.setValidate(true);   
					      mailInfo.setUserName("zwxjava@139.com");   
					      mailInfo.setPassword("a13579");//������������   
					      mailInfo.setFromAddress("zwxjava@139.com");   
					      mailInfo.setToAddress(mailID);   
					      mailInfo.setSubject("����ƽ̨��֤�ʼ�");   
					      mailInfo.setContent("��ӭע��\n������֤���ǣ�"+checkNum+"\n\n\n�����ʼ����Զ����ͣ�����ظ���");   
					         //�������Ҫ�������ʼ�  
					      SimpleMailSender sms = new SimpleMailSender();  
					      if(sms.sendTextMail(mailInfo))//���������ʽ 
					      {JOptionPane.showMessageDialog(null, "���ͳɹ�", "Info", JOptionPane.INFORMATION_MESSAGE);
					      System.out.print("wh");
					      }
						}
						catch(Exception ex)
						{
							ex.printStackTrace();
							JOptionPane.showMessageDialog(null, "����ʧ��", "Warning", JOptionPane.ERROR_MESSAGE);
						}
						
					}
					else{System.out.print("ntmsb");}
				}	
				catch(Exception exx)
				{
					exx.printStackTrace();
				}
			}
		});
		btn_yanz.setFont(new Font("����", Font.PLAIN, 10));
		btn_yanz.setBounds(251, 150, 85, 23);
		getContentPane().add(btn_yanz);
		
		JButton btn_reg = new JButton("\u6CE8\u518C");
		btn_reg.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try{
					UserDao userdao = new UserDao();
					String username = text_username.getText();
					String pwd = text_pwd.getText();
					String rpwd = text_rpwd.getText();
					String mailID= text_email.getText();
					String checkNum = text_yanz.getText();
					if(username.isEmpty() || pwd.isEmpty() || rpwd.isEmpty() || mailID.isEmpty() || checkNum.isEmpty())
					{
						JOptionPane.showMessageDialog(null, "��������д��Ϣ", "Warning", JOptionPane.ERROR_MESSAGE);
						return;
					}
					if(!pwd.equals(rpwd))
					{
						JOptionPane.showMessageDialog(null, "�������벻ƥ��", "Warning", JOptionPane.ERROR_MESSAGE);
						return;
					}
					if(userdao.existUser(username))
					{
						JOptionPane.showMessageDialog(null, "�û����ѱ�ע�ᣡ", "Warning", JOptionPane.ERROR_MESSAGE);
						System.out.print("sb");
						return;
					}
					else
					{
						System.out.print(mailID+"\n"+checkNum);
						if(MailDao.checkMail(mailID, checkNum)){
							userdao.addUser(username,pwd,mailID);
							MailDao.alterType(mailID);
							JOptionPane.showMessageDialog(null, "ע��ɹ���", "Info", JOptionPane.INFORMATION_MESSAGE);
							RegFrame.this.setVisible(false);
						}
						else
						{
							JOptionPane.showMessageDialog(null, "��֤�����", "Warning", JOptionPane.ERROR_MESSAGE);
							return;
						}
						
						System.out.print("tc");
					}
				}
				catch(Exception e){
					e.printStackTrace();
				}
			}
		});
		btn_reg.setBounds(175, 198, 93, 23);
		getContentPane().add(btn_reg);

	}
}
