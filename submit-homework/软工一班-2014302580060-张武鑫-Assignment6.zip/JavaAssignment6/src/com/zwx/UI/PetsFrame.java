package com.zwx.UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PetsFrame extends JFrame {

	private String username;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public PetsFrame(String username) {
		setTitle("\u7F51\u4E0A\u5BA0\u7269\u8D2D\u4E70\u5E73\u53F0");
		this.username = username;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel label = new JLabel("\u5546\u54C1\u8BE6\u60C5");
		label.setBounds(182, 6, 89, 23);
		getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u53F7");
		lblNewLabel.setBounds(45, 41, 60, 15);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5546\u54C1\u540D\u79F0");
		lblNewLabel_1.setBounds(132, 28, 117, 40);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u5546\u54C1\u63CF\u8FF0");
		lblNewLabel_2.setBounds(222, 37, 89, 23);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u5546\u54C1\u5355\u4EF7");
		lblNewLabel_3.setBounds(311, 37, 89, 23);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("1");
		lblNewLabel_4.setBounds(45, 82, 54, 15);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("\u72D7");
		lblNewLabel_5.setBounds(132, 82, 54, 15);
		getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\u6C6A\u6C6A");
		lblNewLabel_6.setBounds(222, 82, 54, 15);
		getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("\uFFE51000");
		lblNewLabel_7.setBounds(311, 82, 54, 15);
		getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("2");
		lblNewLabel_8.setBounds(45, 124, 54, 15);
		getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("\u732B");
		lblNewLabel_9.setBounds(132, 124, 54, 15);
		getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("\u55B5\u545C");
		lblNewLabel_10.setBounds(222, 124, 54, 15);
		getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("\uFFE51024");
		lblNewLabel_11.setBounds(311, 124, 54, 15);
		getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("3");
		lblNewLabel_12.setBounds(45, 170, 54, 15);
		getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("\u9C7C");
		lblNewLabel_13.setBounds(132, 170, 54, 15);
		getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("\u5475\u5475\u54D2");
		lblNewLabel_14.setBounds(222, 170, 54, 15);
		getContentPane().add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("\uFFE5135");
		lblNewLabel_15.setBounds(311, 170, 54, 15);
		getContentPane().add(lblNewLabel_15);
		
		JButton btn_buy = new JButton("\u8D2D\u4E70");
		btn_buy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ShopCart sc = new ShopCart(PetsFrame.this.username);
				sc.setVisible(true);
			}
		});
		btn_buy.setBounds(72, 228, 93, 23);
		getContentPane().add(btn_buy);
		
		JButton btn_hbuy = new JButton("\u67E5\u770B\u5DF2\u8D2D");
		btn_hbuy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				ShopDetail sd = new ShopDetail(PetsFrame.this.username,1);
				sd.setVisible(true);
			}
		});
		btn_hbuy.setBounds(272, 228, 93, 23);
		getContentPane().add(btn_hbuy);
	}
}
