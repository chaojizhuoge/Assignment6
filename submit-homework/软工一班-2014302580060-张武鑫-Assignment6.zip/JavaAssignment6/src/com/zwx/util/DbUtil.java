package com.zwx.util;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.UnsupportedEncodingException;
//import java.sql.Blob;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.SQLException;
import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;
public class DbUtil {
	//�������������ַ���
	private final static String CONNECTION_DRIVER_STR = "com.mysql.jdbc.Driver";
	private final static String CONNECTION_STR = "jdbc:mysql://127.0.0.1:3306/my_schema?useUnicode=true&amp;amp;characterEncoding=utf-8";
	//���ݿ��û���
	private final static String DB_USER_NAME = "root";
	//���ݿ�����
	private final static String DB_PWD = "123456";
	
	/**
	 * ��ȡ���ݿ�����
	 * @return
	 */
	public static Connection getConnection() {
	    Connection conn = null;
	    try {
	        Class.forName(CONNECTION_DRIVER_STR);
	        conn = DriverManager.getConnection(CONNECTION_STR, DB_USER_NAME, DB_PWD);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return conn;
	}
	/**
	 * �ر����ݿ�����
	 * @param con
	 * @param st
	 * @param rss
	 */
	public static void closeConnection(Connection con,Statement st,ResultSet rss)  {
		try {
			if(null != rss) {
				rss.close();
			}
		}catch(Exception e) {
			rss = null;
		}
		try {
			st.close();
		}catch(Exception e) {
			st = null;
		}
		try {
			con.close();
		}catch(Exception e) {
			con = null;
		}
	}
}
