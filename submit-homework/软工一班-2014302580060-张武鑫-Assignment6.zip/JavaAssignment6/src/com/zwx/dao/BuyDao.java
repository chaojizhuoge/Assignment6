package com.zwx.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zwx.util.DbUtil;

public class BuyDao {

	public static void addProd(String username,String pid, String num) throws Exception
	{
		String sql = "insert into 2014302580060_buy(username,pid,num) values('"+username+"','"+pid+"','"+num+"')";
		Connection con = null;
		Statement st = null;
		try {
		   con = DbUtil.getConnection();//获取数据库连接
		   st = con.createStatement();
		   st.executeUpdate(sql);
		   //System.out.print("cb");
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, null);
		}
	}
	
	public static List<Map<String,Object>> findProd(String username)
	{
		String sql = "select * from 2014302580060_buy where username = '"+username+"'";
		Connection con = null;
		Statement st = null;
		ResultSet rss = null;
		Map<String,Object> map = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try{
			con = DbUtil.getConnection();//��ȡ��ݿ�����
			st = con.createStatement();
			rss = st.executeQuery(sql);
			while(rss.next()) {
				map=new HashMap<String,Object>();
				map.put("username", rss.getObject("username"));
				//map.put("messageID", rss.getObject("messageID"));
				//map.put("groupID", rss.getObject("groupID"));
				//map.put("uploadTime", rss.getObject("uploadTime"));
				//map.put("startTime", rss.getObject("startTime"));
				map.put("pid", rss.getObject("pid"));
				map.put("num", rss.getObject("num"));
				//map.put("img", new File())
				list.add(map);	
				
			}
			
			for(int i = 0;i<list.size()-1;i++)
			{
				for(int j = list.size()-1;j>i;j--)
				{
					if(((String)list.get(j).get("username")).equals((String)list.get(i).get("username")) && (int)list.get(j).get("pid")==(int)list.get(i).get("pid"))
						{
							list.get(i).put("num", (int)list.get(i).get("num") + (int)list.get(j).get("num"));
							list.remove(j);
						}
				}
			}
			
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, rss);
		}
		return list;
	}


}
