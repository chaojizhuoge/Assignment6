package com.zwx.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





import com.zwx.util.DbUtil;
public class MailDao {
	public static void addMailCheck(String mailID,String checkNum) throws Exception
	{
		String sql = "insert into 2014302580060_mailCheck(mailID,checkNum,type) values('"+mailID+"','"+checkNum+"',1)";
		Connection con = null;
		Statement st = null;
		try {
		   con = DbUtil.getConnection();//��ȡ���ݿ�����
		   st = con.createStatement();
		   st.executeUpdate(sql);
		   //System.out.print("cb");
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, null);
		}
	}
	
	public static boolean existMail(String mailID,int type) throws Exception
	{
		String sql = "select * from 2014302580060_mailCheck where mailID='"+mailID+"' AND type="+type;
		Connection con = null;
		Statement st = null;
		ResultSet rss = null;
		try{
			con = DbUtil.getConnection();//��ȡ���ݿ�����
			st = con.createStatement();
			rss = st.executeQuery(sql);
			if(rss.next()) {
				
					return true;
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.closeConnection(con, st, rss);
		}
		return false;
	}
	
	public static void deleteFromMail(String mailID) throws Exception
	{
		String sql = "delete from 2014302580060_mailCheck where mailID='"+mailID+"' AND type=1";
		Connection con = null;
		Statement st = null;
		try {
		   con = DbUtil.getConnection();//��ȡ���ݿ�����
		   st = con.createStatement();
		   st.executeUpdate(sql);
		   //System.out.print("cb");
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, null);
		}
	}
	
	public static boolean checkMail(String mailID,String checkNum) throws Exception
	{
		String sql = "select * from 2014302580060_mailCheck where mailID='"+mailID+"' AND checkNum='"+checkNum+"'";
		Connection con = null;
		Statement st = null;
		ResultSet rss = null;
		try{
			con = DbUtil.getConnection();//��ȡ���ݿ�����
			st = con.createStatement();
			rss = st.executeQuery(sql);
			if(rss.next()) {
				
					return true;
				
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DbUtil.closeConnection(con, st, rss);
		}
		return false;
	}
	
	public static void alterType(String mailID)
	{
		String sql = "update 2014302580060_mailCheck set type=2 where mailID='"+mailID+"' AND type=1";
		Connection con = null;
		Statement st = null;
		try {
		   con = DbUtil.getConnection();//��ȡ���ݿ�����
		   st = con.createStatement();
		   st.executeUpdate(sql);
		   //System.out.print("cb");
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, null);
		}
	}
}
