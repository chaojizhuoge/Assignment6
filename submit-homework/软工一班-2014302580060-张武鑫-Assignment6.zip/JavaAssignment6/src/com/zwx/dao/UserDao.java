package com.zwx.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.zwx.util.DbUtil;

public class UserDao {
	/**
	 * �û���¼��֤
	 * @param userName
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	public boolean checkUser(String userName,String pwd) throws Exception {
		String sql = "select * from 2014302580060_user where id='"+userName+"' AND pwd='"+pwd+"'";
		Connection con = null;
		Statement st = null;
		ResultSet rss = null;
		try{
			con = DbUtil.getConnection();//��ȡ���ݿ�����
			st = con.createStatement();
			rss = st.executeQuery(sql);
			if(rss.next()) {
				
					return true;
				
			}
		}catch(Exception e) {
			
		}finally {
			DbUtil.closeConnection(con, st, rss);
		}
		return false;
	}
	/**
	 * �û�ע����֤
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	public boolean existUser(String userName) throws Exception {
		String sql = "select * from 2014302580060_user where id='"+userName+"'";
		Connection con = null;
		Statement st = null;
		ResultSet rss = null;
		try{
			con = DbUtil.getConnection();//��ȡ���ݿ�����
			st = con.createStatement();
			rss = st.executeQuery(sql);
			if(rss.next()) {
				
					return true;
				
			}
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, rss);
		}
		return false;
	}
	/**
	 * �����û���Ϣ
	 * @param user
	 * @throws Exception
	 */
	public void addUser(String userid, String pwd, String email) throws Exception {
		String sql = "insert into 2014302580060_user(id,pwd,email) values('"+userid+"','"+pwd+"','"+email+"')";
		Connection con = null;
		Statement st = null;
		try {
		   con = DbUtil.getConnection();//��ȡ���ݿ�����
		   st = con.createStatement();
		   st.executeUpdate(sql);
		   //System.out.print("cb");
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			DbUtil.closeConnection(con, st, null);
		}
	}

}
